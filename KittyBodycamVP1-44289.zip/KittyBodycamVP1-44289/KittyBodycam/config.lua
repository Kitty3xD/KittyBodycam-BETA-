Config = {}

Config.MaxUnitNumberLength = 24
Config.DefaultOverlay = 'axon'
Config.BeepIntervalMs = 60000
Config.MaxCallsignLength = 16
Config.CallsignPattern = '^[%d][%a]%-?%d+$'
Config.CallsignExample = '3L-061'
Config.Departments = {
    ['1'] = 'City',
    ['2'] = 'Highway Patrol',
    ['3'] = 'County'
}
Config.MaxDepartmentMessageLength = 280

Config.DiscordPermissions = {
    Enabled = false,
    EmployeeRoleIds = {},
    SupervisorRoleIds = {}
}
