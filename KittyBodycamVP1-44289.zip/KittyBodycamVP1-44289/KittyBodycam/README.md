# Kitty Bodycam

A standalone FiveM bodycam resource with an English configuration menu, Axon- and Motorola-inspired overlays, a chest-mounted camera view, and a live-view phone.

## Features

- `/bodycam` opens a hardware-style bodycam control screen with the supplied Axon and Motorola camera images.
- `/kphone` opens KittyOS 98. Sign in with a callsign before using `/bodycam`; signing out ends the duty session and stops your bodycam.
- Callsign prefixes select departments. Defaults: `1` City, `2` Highway Patrol, and `3` County. For example, `3L-061` signs into County as unit 061.
- Callsign format/example, department prefixes, callsign length, and department-message length are configurable in `config.lua`.
- Signed-in staff can send a department-wide message to all on-duty staff with the same callsign prefix.
- `config.lua` has separate `EmployeeRoleIds` (system access) and `SupervisorRoleIds` placeholders. Discord authorization is not integrated and remains disabled.
- The service number shown on the HUD is derived from the trailing digits of the signed-in callsign (for example, `3L-061` displays `061`).
- Press the camera's center control to start; choose **HUD only** or **HUD + chest camera**.
- Use the HUD control on the device to move the Axon HUD anywhere or move the Motorola HUD vertically.
- Reopen `/bodycam` and press the center control to stop an active bodycam.
- The device control screen closes when recording starts, leaving the HUD/game camera visible.
- The signed-in KittyOS Bodycam Monitor shows live feeds from your department.
- The chest and live camera views respond to mouse movement; the chest camera adds stronger movement sway when sprinting.
- Axon uses `html/bodycam-beep.mp3` and Motorola uses `html/motorola-beep.mp3` for their respective startup chirps and once-per-minute status beeps.
- Press Backspace to exit a live view.
- The phone uses a light, Windows 98-inspired KittyOS interface with the supplied Kitty logo.
- The phone's Settings page shows your current KittyID (FiveM server ID).
- The phone shows active bodycam live feeds only; the resource does not save video, audio, or event history.
- `/bodycamreset` stops this resource's camera feeds and releases NUI focus if the display gets stuck.
- Players can view active bodycams by player and service number.
- Preferences are saved locally for the player.

The Axon-style overlay uses the supplied Axon logo with the background removed, alongside a transparent timestamp and unit number; the Motorola-style overlay uses a slim dark header with the device brand, UTC timestamp, and service number. Images and beep audio are embedded as data URLs in `html/embedded-assets.js` so they do not depend on FiveM's resource-file URL handling. Keep that bundle with the resource; regenerate it from the six source assets when any image or sound changes.

## Installation

1. Copy the `KittyBodycam` folder into the server's `resources` directory.
2. Add `ensure KittyBodycam` to `server.cfg`.
3. Restart the resource or server.

## Notes

The chest-mounted view tracks the ped's chest and shoulder-bone positions every frame, adds stronger speed-based sway when sprinting, and supports bounded mouse-look. While aiming, the camera holds its heading reference so weapon-aim rotation cannot feed back into the camera and cause spinning. The local player model is kept visible, and the camera is positioned in front of the chest, angled slightly down. Live feeds are open to all players and require the target player to be in the viewer's network streaming range. Live video is not recorded or stored; device beeps are played locally by the NUI.


## UI updates

- Subtle synthesized UI click tones play when the phone/menu controls are used.
- The bodycam picker is now transparent and simplified, with the device choices and help hints remaining visible.
- The phone includes an Officers tab showing on-duty colleagues from the same configured department prefix, plus a schematic overview of active bodycam positions.
- The phone marks the Dashcam feature as coming soon. Dashcam recording itself is not implemented yet.

The active-bodycam overview is a schematic based on GTA world coordinates, not a street-map tile layer. Officer and camera status refresh when the Officers tab is opened or the phone refresh control is used.
