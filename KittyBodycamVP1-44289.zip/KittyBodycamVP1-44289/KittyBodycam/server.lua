local bodycams = {}
local activeViewers = {}
local onDuty = {}
DeleteResourceKvp('kittybodycam:event-history')

local function cleanCallsign(value)
    if type(value) ~= 'string' then
        return nil
    end

    local callsign = value:upper():gsub('%s+', '')
    if #callsign == 0 or #callsign > Config.MaxCallsignLength
        or not callsign:match(Config.CallsignPattern) then
        return nil
    end

    local prefix = callsign:sub(1, 1)
    local department = Config.Departments[prefix]
    if not department then
        return nil
    end

    return callsign, prefix, department
end

local function cleanUnitNumber(value)
    if type(value) ~= 'string' then
        return ''
    end

    value = value:gsub('[^%w%- ]', '')
    return value:sub(1, Config.MaxUnitNumberLength)
end

local function sendDutyState(playerId)
    local officer = onDuty[playerId]
    if officer then
        TriggerClientEvent('kittybodycam:dutyState', playerId, {
            active = true,
            callsign = officer.callsign,
            prefix = officer.prefix,
            department = officer.department,
            kittyId = tostring(playerId),
            maxCallsignLength = Config.MaxCallsignLength,
            maxDepartmentMessageLength = Config.MaxDepartmentMessageLength,
            departments = Config.Departments,
            callsignExample = Config.CallsignExample
        })
    else
        TriggerClientEvent('kittybodycam:dutyState', playerId, {
            active = false,
            maxCallsignLength = Config.MaxCallsignLength,
            maxDepartmentMessageLength = Config.MaxDepartmentMessageLength,
            departments = Config.Departments,
            callsignExample = Config.CallsignExample
        })
    end
end

local function stopViewersOf(targetId)
    for viewerId, viewedTargetId in pairs(activeViewers) do
        if viewedTargetId == targetId then
            activeViewers[viewerId] = nil
            TriggerClientEvent('kittybodycam:stopRemoteView', viewerId)
        end
    end
end

RegisterNetEvent('kittybodycam:requestDutyState', function()
    sendDutyState(source)
end)

RegisterNetEvent('kittybodycam:loginDuty', function(value)
    local playerId = source
    local callsign, prefix, department = cleanCallsign(value)
    if not callsign then
        TriggerClientEvent('kittybodycam:loginResult', playerId, {
            success = false,
            message = ('Invalid callsign or department prefix. Example: %s.'):format(Config.CallsignExample)
        })
        return
    end

    for otherId, officer in pairs(onDuty) do
        if otherId ~= playerId and officer.callsign == callsign then
            TriggerClientEvent('kittybodycam:loginResult', playerId, {
                success = false,
                message = 'That callsign is already signed in.'
            })
            return
        end
    end

    onDuty[playerId] = {
        callsign = callsign,
        prefix = prefix,
        department = department
    }
    TriggerClientEvent('kittybodycam:loginResult', playerId, {
        success = true,
        callsign = callsign,
        prefix = prefix,
        department = department,
        kittyId = tostring(playerId),
        maxCallsignLength = Config.MaxCallsignLength,
        maxDepartmentMessageLength = Config.MaxDepartmentMessageLength,
        departments = Config.Departments
    })
end)

RegisterNetEvent('kittybodycam:logoutDuty', function()
    local playerId = source
    onDuty[playerId] = nil
    bodycams[playerId] = nil
    stopViewersOf(playerId)
    activeViewers[playerId] = nil
    sendDutyState(playerId)
    TriggerClientEvent('kittybodycam:stopRemoteView', playerId)
    TriggerClientEvent('kittybodycam:bodycamForcedStop', playerId)
end)

RegisterNetEvent('kittybodycam:sendDepartmentMessage', function(message)
    local senderId = source
    local sender = onDuty[senderId]
    if not sender then
        TriggerClientEvent('kittybodycam:phoneMessageError', senderId, 'Sign in on KittyOS before sending a service message.')
        return
    end
    if type(message) ~= 'string' then
        TriggerClientEvent('kittybodycam:phoneMessageError', senderId, 'Message must be text.')
        return
    end

    message = message:gsub('[\r\n]+', ' '):gsub('%s+', ' '):match('^%s*(.-)%s*$')
    if #message == 0 or #message > Config.MaxDepartmentMessageLength then
        TriggerClientEvent('kittybodycam:phoneMessageError', senderId, ('Message must be between 1 and %d characters.'):format(Config.MaxDepartmentMessageLength))
        return
    end

    local notice = {
        callsign = sender.callsign,
        department = sender.department,
        message = message,
        timestamp = os.time()
    }
    for recipientId, officer in pairs(onDuty) do
        if officer.prefix == sender.prefix then
            TriggerClientEvent('kittybodycam:departmentMessage', recipientId, notice)
        end
    end
    TriggerClientEvent('kittybodycam:departmentMessageSent', senderId)
end)

local function sendFeedList(playerId)
    local feeds = {}
    local viewer = onDuty[playerId]
    for sourceId, state in pairs(bodycams) do
        if state.active and onDuty[sourceId] and viewer and onDuty[sourceId].prefix == viewer.prefix then
            feeds[#feeds + 1] = {
                serverId = sourceId,
                unitNumber = state.unitNumber,
                overlay = state.overlay,
                playerName = GetPlayerName(sourceId) or ('Player ' .. sourceId),
                callsign = onDuty[sourceId].callsign
            }
        end
    end

    TriggerClientEvent('kittybodycam:feedList', playerId, feeds)
end

RegisterNetEvent('kittybodycam:updateState', function(state)
    local playerId = source
    if type(state) ~= 'table' then
        return
    end

    local officer = onDuty[playerId]
    local isActive = state.active == true and officer ~= nil
    local unitNumber = officer and cleanUnitNumber(officer.callsign:match('%d+$') or officer.callsign) or ''

    if isActive then
        bodycams[playerId] = {
            active = true,
            unitNumber = unitNumber,
            overlay = state.overlay == 'motorola' and 'motorola' or Config.DefaultOverlay
        }
    else
        bodycams[playerId] = nil
        stopViewersOf(playerId)
    end
end)

RegisterNetEvent('kittybodycam:requestFeeds', function()
    sendFeedList(source)
end)

RegisterNetEvent('kittybodycam:requestDutyRoster', function()
    local playerId = source
    local viewer = onDuty[playerId]
    local roster = {}
    if viewer then
        for officerId, officer in pairs(onDuty) do
            if officer.prefix == viewer.prefix then
                local ped = GetPlayerPed(officerId)
                local coords = ped and ped ~= 0 and GetEntityCoords(ped) or nil
                local cam = bodycams[officerId]
                roster[#roster + 1] = {
                    serverId = officerId,
                    callsign = officer.callsign,
                    department = officer.department,
                    playerName = GetPlayerName(officerId) or ('Player ' .. officerId),
                    active = cam ~= nil and cam.active == true,
                    x = coords and coords.x or nil,
                    y = coords and coords.y or nil
                }
            end
        end
    end
    TriggerClientEvent('kittybodycam:dutyRoster', playerId, roster)
end)


local privateMessages = {}

RegisterNetEvent('kittybodycam:sendPrivateMessage', function(targetId, message)
    local senderId = source
    targetId = tonumber(targetId)
    local sender, recipient = onDuty[senderId], targetId and onDuty[targetId]
    if not sender or not recipient or targetId == senderId or sender.prefix ~= recipient.prefix then
        TriggerClientEvent('kittybodycam:privateMessageError', senderId, 'Officer is no longer available in your department.')
        return
    end
    if type(message) ~= 'string' then return end
    message = message:gsub('[\r\n]+', ' '):gsub('%s+', ' '):match('^%s*(.-)%s*$')
    if #message < 1 or #message > Config.MaxDepartmentMessageLength then
        TriggerClientEvent('kittybodycam:privateMessageError', senderId, ('Message must be 1-%d characters.'):format(Config.MaxDepartmentMessageLength))
        return
    end
    local entry = { fromId = senderId, toId = targetId, fromCallsign = sender.callsign, toCallsign = recipient.callsign, message = message, timestamp = os.time() }
    privateMessages[#privateMessages + 1] = entry
    if #privateMessages > 200 then table.remove(privateMessages, 1) end
    TriggerClientEvent('kittybodycam:privateMessage', senderId, entry)
    TriggerClientEvent('kittybodycam:privateMessage', targetId, entry)
end)

RegisterNetEvent('kittybodycam:requestPrivateHistory', function(targetId)
    local playerId = source
    targetId = tonumber(targetId)
    local viewer, target = onDuty[playerId], targetId and onDuty[targetId]
    if not viewer or not target or viewer.prefix ~= target.prefix then return end
    local history = {}
    for _, entry in ipairs(privateMessages) do
        if (entry.fromId == playerId and entry.toId == targetId) or (entry.fromId == targetId and entry.toId == playerId) then
            history[#history + 1] = entry
        end
    end
    TriggerClientEvent('kittybodycam:privateHistory', playerId, targetId, history)
end)

RegisterNetEvent('kittybodycam:requestPhoneInfo', function()
    local officer = onDuty[source]
    TriggerClientEvent('kittybodycam:phoneInfo', source, {
        kittyId = tostring(source),
        callsign = officer and officer.callsign or '',
        department = officer and officer.department or ''
    })
end)

RegisterNetEvent('kittybodycam:requestLive', function(targetId)
    local viewerId = source
    targetId = tonumber(targetId)
    if not onDuty[viewerId] then
        TriggerClientEvent('kittybodycam:liveError', viewerId, 'Sign in on KittyOS before opening a live feed.')
        return
    end
    if not targetId or not bodycams[targetId] or not bodycams[targetId].active or not onDuty[targetId]
        or onDuty[targetId].prefix ~= onDuty[viewerId].prefix then
        TriggerClientEvent('kittybodycam:liveError', viewerId, 'That bodycam is no longer available.')
        return
    end

    TriggerClientEvent('kittybodycam:startRemoteView', viewerId, {
        serverId = targetId,
        unitNumber = bodycams[targetId].unitNumber,
        overlay = bodycams[targetId].overlay,
        playerName = GetPlayerName(targetId) or ('Player ' .. targetId)
    })
    activeViewers[viewerId] = targetId
end)

RegisterNetEvent('kittybodycam:stopLive', function()
    activeViewers[source] = nil
    TriggerClientEvent('kittybodycam:stopRemoteView', source)
end)

AddEventHandler('playerDropped', function()
    bodycams[source] = nil
    activeViewers[source] = nil
    stopViewersOf(source)
    onDuty[source] = nil
end)

CreateThread(function()
    while true do
        Wait(60000)
        for viewerId, targetId in pairs(activeViewers) do
            if not GetPlayerName(viewerId) or not bodycams[targetId] or not bodycams[targetId].active then
                activeViewers[viewerId] = nil
                TriggerClientEvent('kittybodycam:stopRemoteView', viewerId)
            end
        end
    end
end)
