local bodycam = {
    active = false,
    overlay = GetResourceKvpString('kittybodycam:overlay') or Config.DefaultOverlay,
    mode = GetResourceKvpString('kittybodycam:mode') or 'overlay',
    unitNumber = GetResourceKvpString('kittybodycam:unit') or ''
}
local dutySession = {
    active = false,
    callsign = '',
    department = '',
    kittyId = ''
}
local phoneOpen = false

local bodycamCamera
local previousGameplayViewMode
local remoteCamera
local remoteTargetId
local lastBeepAt
local previousBodycamActive = false
local chestBoneId = 24818
local leftShoulderBoneId = 64729
local rightShoulderBoneId = 10706
local cameraLookYaw = 0.0
local cameraLookPitch = 0.0
local cameraBaseHeading = 0.0
local cameraWasAiming = false

local function normalizeHeading(heading)
    return (heading % 360.0 + 360.0) % 360.0
end

local function getCameraAimState(ped)
    if ped == PlayerPedId() then
        return IsPlayerFreeAiming(PlayerId())
    end

    if remoteTargetId then
        local player = GetPlayerFromServerId(remoteTargetId)
        return player ~= -1 and IsPlayerFreeAiming(player)
    end

    return false
end

local function clampPosition(value)
    return math.max(0.0, math.min(1.0, value))
end

local function getAxonPosition()
    local savedPosition = GetResourceKvpString('kittybodycam:axon-position')
    if savedPosition then
        local x, y = savedPosition:match('^([%d%.]+),([%d%.]+)$')
        x, y = tonumber(x), tonumber(y)
        if x and y then
            return clampPosition(x), clampPosition(y)
        end
    end
    return 0.02, 0.02
end

local function getMotorolaPositionY()
    local savedPosition = tonumber(GetResourceKvpString('kittybodycam:motorola-position-y'))
    if savedPosition then
        return clampPosition(savedPosition)
    end
    return 0.02
end

local axonPositionX, axonPositionY = getAxonPosition()
local motorolaPositionY = getMotorolaPositionY()

local function notify(message)
    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName(message)
    EndTextCommandThefeedPostTicker(false, false)
end

local function updateBodyCameraTransform(camera, ped)
    if not DoesEntityExist(ped) then
        return false
    end

    -- Keep this as a custom, shoulder/chest-mounted camera (not native first person).
    -- A head-bone camera sits inside the head/neck mesh and can occlude the arms.
    local boneIndex = GetPedBoneIndex(ped, chestBoneId) -- SKEL_Spine2 / upper chest
    if boneIndex == -1 then
        boneIndex = GetPedBoneIndex(ped, 24816) -- SKEL_Spine1 fallback
    end
    if boneIndex == -1 then
        return false
    end

    local chestPosition = GetWorldPositionOfEntityBone(ped, boneIndex)
    local forward = GetEntityForwardVector(ped)
    local right = vector3(forward.y, -forward.x, 0.0)
    local speed = GetEntitySpeed(ped)
    local movement = math.min(speed / 2.6, 1.0)
    local now = GetGameTimer() / 1000.0
    local gaitRate = IsPedSprinting(ped) and 11.0 or 7.0
    local gait = now * gaitRate
    local sprintMultiplier = IsPedSprinting(ped) and 1.8 or 1.0
    local lateralSway = math.sin(gait) * 0.035 * movement * sprintMultiplier
    local verticalBob = math.abs(math.cos(gait)) * 0.045 * movement * sprintMultiplier
    local pitchSway = math.sin(gait) * 1.5 * movement * sprintMultiplier
    local rollSway = math.sin(gait) * 1.5 * movement * sprintMultiplier

    -- Slightly above and in front of the upper chest, but not inside the head.
    -- Keeping a small backward offset from the chest helps show both arms and the weapon.
    SetCamCoord(
        camera,
        chestPosition.x + forward.x * 0.16 + right.x * lateralSway,
        chestPosition.y + forward.y * 0.16 + right.y * lateralSway,
        chestPosition.z + 0.16 + verticalBob * 0.25
    )

    local isAiming = getCameraAimState(ped)
    local pedHeading = GetEntityHeading(ped)
    if isAiming then
        if not cameraWasAiming then
            cameraBaseHeading = pedHeading
        end
    else
        if cameraWasAiming then
            local previousHeading = normalizeHeading(cameraBaseHeading + cameraLookYaw)
            local offset = (previousHeading - pedHeading + 540.0) % 360.0 - 180.0
            cameraLookYaw = math.max(-85.0, math.min(85.0, offset))
        end
        cameraBaseHeading = pedHeading
    end
    cameraWasAiming = isAiming

    if isAiming and ped == PlayerPedId() then
        -- Follow the actual aim pitch/yaw so the weapon stays aligned with the view.
        local aimRot = GetGameplayCamRot(2)
        SetCamRot(camera, aimRot.x, 0.0, aimRot.z, 2)
    else
        SetCamRot(camera, -8.0 + pitchSway + cameraLookPitch, rollSway, normalizeHeading(cameraBaseHeading + cameraLookYaw), 2)
    end

    if ped == PlayerPedId() then
        SetEntityLocallyVisible(ped)
    end
    return true
end

local function setBodycamCamera(enabled)
    -- Scripted body-worn POV: place the camera at the officer's head/upper chest,
    -- rather than switching GTA into its native first-person gameplay mode.
    if enabled then
        if bodycamCamera and DoesCamExist(bodycamCamera) then return end
        local ped = PlayerPedId()
        bodycamCamera = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
        SetCamFov(bodycamCamera, 82.0)
        cameraLookYaw = 0.0
        cameraLookPitch = 0.0
        cameraBaseHeading = GetEntityHeading(ped)
        cameraWasAiming = false
        if not updateBodyCameraTransform(bodycamCamera, ped) then
            DestroyCam(bodycamCamera, false)
            bodycamCamera = nil
            return
        end
        SetCamActive(bodycamCamera, true)
        RenderScriptCams(true, true, 250, true, true)
        return
    end

    if bodycamCamera then
        RenderScriptCams(false, true, 200, true, true)
        if DoesCamExist(bodycamCamera) then
            DestroyCam(bodycamCamera, false)
        end
        bodycamCamera = nil
    end
end

local function setRemoteCamera(targetId)
    local player = GetPlayerFromServerId(targetId)
    if player == -1 then
        return false
    end

    local ped = GetPlayerPed(player)
    if not DoesEntityExist(ped) then
        return false
    end

    if remoteCamera then
        DestroyCam(remoteCamera, false)
    end
    cameraLookYaw = 0.0
    cameraLookPitch = 0.0
    cameraBaseHeading = GetEntityHeading(ped)
    cameraWasAiming = false
    remoteCamera = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
    SetCamFov(remoteCamera, 95.0)
    if not updateBodyCameraTransform(remoteCamera, ped) then
        DestroyCam(remoteCamera, false)
        remoteCamera = nil
        return false
    end
    SetCamActive(remoteCamera, true)
    RenderScriptCams(true, true, 350, true, true)
    remoteTargetId = targetId
    return true
end

local function stopRemoteCamera(restoreBodycam)
    if remoteCamera then
        RenderScriptCams(false, true, 250, true, true)
        DestroyCam(remoteCamera, false)
        remoteCamera = nil
    end
    remoteTargetId = nil

    if restoreBodycam ~= false and bodycam.active and bodycam.mode == 'chest' then
        setBodycamCamera(true)
    end
end

local function persistSettings()
    SetResourceKvp('kittybodycam:overlay', bodycam.overlay)
    SetResourceKvp('kittybodycam:mode', bodycam.mode)
    SetResourceKvp('kittybodycam:unit', bodycam.unitNumber)
end

local function updateBodycam()
    if bodycam.active ~= previousBodycamActive then
        lastBeepAt = bodycam.active and GetGameTimer() or nil
        if bodycam.active then
            SendNUIMessage({ action = 'deviceBeep', overlay = bodycam.overlay })
        end
        previousBodycamActive = bodycam.active
    end

    local useCamera = bodycam.active and bodycam.mode == 'chest'
    setBodycamCamera(useCamera)

    SendNUIMessage({
        action = 'bodycamState',
        active = bodycam.active,
        overlay = bodycam.overlay,
        mode = bodycam.mode,
        unitNumber = bodycam.unitNumber,
        axonPositionX = axonPositionX,
        axonPositionY = axonPositionY,
        motorolaPositionY = motorolaPositionY
    })

    TriggerServerEvent('kittybodycam:updateState', {
        active = bodycam.active,
        overlay = bodycam.overlay,
        unitNumber = bodycam.unitNumber
    })
end

local function openMenu()
    if not dutySession.active then
        notify('Sign in through /kphone before using your bodycam.')
        return
    end
    if remoteCamera then
        notify('Close the live feed before opening the bodycam menu.')
        return
    end

    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'openBodycamMenu',
        active = bodycam.active,
        overlay = bodycam.overlay,
        mode = bodycam.mode,
        unitNumber = bodycam.unitNumber,
        axonPositionX = axonPositionX,
        axonPositionY = axonPositionY,
        motorolaPositionY = motorolaPositionY
    })
end

local function openPhone()
    if remoteCamera then
        notify('Close the live feed before opening the phone.')
        return
    end

    phoneOpen = true
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'openPhone' })
    TriggerServerEvent('kittybodycam:requestDutyState')
end

RegisterCommand('bodycam', openMenu, false)
RegisterCommand('kphone', openPhone, false)

RegisterCommand('bodycamreset', function()
    bodycam.active = false
    stopRemoteCamera(false)
    setBodycamCamera(false)
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'stopLive' })
    SendNUIMessage({
        action = 'bodycamState',
        active = false,
        overlay = bodycam.overlay,
        mode = bodycam.mode,
        unitNumber = bodycam.unitNumber
    })
    TriggerServerEvent('kittybodycam:updateState', {
        active = false,
        overlay = bodycam.overlay,
        unitNumber = bodycam.unitNumber
    })
    notify('Bodycam cameras and interface have been reset.')
end, false)

RegisterNUICallback('close', function(_, callback)
    phoneOpen = false
    SetNuiFocus(false, false)
    callback({ ok = true })
end)

RegisterNUICallback('loginDuty', function(data, callback)
    if type(data) == 'table' and type(data.callsign) == 'string' then
        TriggerServerEvent('kittybodycam:loginDuty', data.callsign)
    end
    callback({ ok = true })
end)

RegisterNUICallback('logoutDuty', function(_, callback)
    TriggerServerEvent('kittybodycam:logoutDuty')
    callback({ ok = true })
end)

RegisterNUICallback('sendDepartmentMessage', function(data, callback)
    if type(data) == 'table' and type(data.message) == 'string' then
        TriggerServerEvent('kittybodycam:sendDepartmentMessage', data.message)
    end
    callback({ ok = true })
end)

RegisterNUICallback('setBodycam', function(data, callback)
    if type(data) == 'table' then
        if data.overlay == 'axon' or data.overlay == 'motorola' then
            bodycam.overlay = data.overlay
        end
        if data.mode == 'overlay' or data.mode == 'chest' then
            bodycam.mode = data.mode
        end
        if type(data.unitNumber) == 'string' then
            bodycam.unitNumber = data.unitNumber:sub(1, Config.MaxUnitNumberLength)
        end
        if type(data.active) == 'boolean' then
            bodycam.active = data.active
        end

        persistSettings()
        updateBodycam()
    end
    callback({ ok = true })
end)

RegisterNUICallback('refreshFeeds', function(_, callback)
    TriggerServerEvent('kittybodycam:requestFeeds')
    callback({ ok = true })
end)

RegisterNUICallback('requestPhoneInfo', function(_, callback)
    TriggerServerEvent('kittybodycam:requestPhoneInfo')
    callback({ ok = true })
end)

RegisterNUICallback('requestDutyRoster', function(_, callback)
    TriggerServerEvent('kittybodycam:requestDutyRoster')
    callback({ ok = true })
end)

RegisterNetEvent('kittybodycam:dutyRoster', function(roster)
    SendNUIMessage({ action = 'dutyRoster', officers = roster or {} })
end)

RegisterNUICallback('sendPrivateMessage', function(data, callback)
    if type(data) == 'table' then TriggerServerEvent('kittybodycam:sendPrivateMessage', data.targetId, data.message) end
    callback({ ok = true })
end)

RegisterNUICallback('requestPrivateHistory', function(data, callback)
    if type(data) == 'table' then TriggerServerEvent('kittybodycam:requestPrivateHistory', data.targetId) end
    callback({ ok = true })
end)

RegisterNetEvent('kittybodycam:privateMessage', function(message)
    SendNUIMessage({ action = 'privateMessage', message = message })
    notify(('Private message from %s'):format(message.fromCallsign or 'Officer'))
end)
RegisterNetEvent('kittybodycam:privateHistory', function(targetId, messages)
    SendNUIMessage({ action = 'privateHistory', targetId = targetId, messages = messages or {} })
end)
RegisterNetEvent('kittybodycam:privateMessageError', function(message)
    SendNUIMessage({ action = 'privateMessageError', message = message })
end)

RegisterNUICallback('setAxonPosition', function(data, callback)
    if type(data) == 'table' and type(data.x) == 'number' and type(data.y) == 'number' then
        axonPositionX = clampPosition(data.x)
        axonPositionY = clampPosition(data.y)
        SetResourceKvp('kittybodycam:axon-position', string.format('%.4f,%.4f', axonPositionX, axonPositionY))
        SendNUIMessage({
            action = 'axonPosition',
            x = axonPositionX,
            y = axonPositionY
        })
    end
    SetNuiFocus(false, false)
    callback({ ok = true })
end)

RegisterNUICallback('setMotorolaPosition', function(data, callback)
    if type(data) == 'table' and type(data.y) == 'number' then
        motorolaPositionY = clampPosition(data.y)
        SetResourceKvp('kittybodycam:motorola-position-y', string.format('%.4f', motorolaPositionY))
        SendNUIMessage({
            action = 'motorolaPosition',
            y = motorolaPositionY
        })
    end
    SetNuiFocus(false, false)
    callback({ ok = true })
end)

RegisterNUICallback('watchFeed', function(data, callback)
    if type(data) == 'table' and tonumber(data.serverId) then
        TriggerServerEvent('kittybodycam:requestLive', tonumber(data.serverId))
    end
    callback({ ok = true })
end)

RegisterNUICallback('stopLive', function(_, callback)
    TriggerServerEvent('kittybodycam:stopLive')
    stopRemoteCamera()
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'stopLive' })
    callback({ ok = true })
end)

RegisterNetEvent('kittybodycam:feedList', function(feeds)
    SendNUIMessage({ action = 'feedList', feeds = feeds })
end)

RegisterNetEvent('kittybodycam:phoneInfo', function(kittyId)
    if type(kittyId) == 'table' then
        SendNUIMessage({ action = 'phoneInfo', kittyId = kittyId.kittyId, callsign = kittyId.callsign, department = kittyId.department })
    else
        SendNUIMessage({ action = 'phoneInfo', kittyId = kittyId })
    end
end)

RegisterNetEvent('kittybodycam:dutyState', function(state)
    dutySession.active = type(state) == 'table' and state.active == true
    if dutySession.active then
        dutySession.callsign = state.callsign or ''
        dutySession.department = state.department or ''
        dutySession.kittyId = state.kittyId or ''
        bodycam.unitNumber = dutySession.callsign:match('%d+$') or dutySession.callsign
    else
        dutySession.callsign = ''
        dutySession.department = ''
        dutySession.kittyId = ''
    end
    SendNUIMessage({
        action = 'dutyState',
        active = dutySession.active,
        callsign = dutySession.callsign,
        department = dutySession.department,
        kittyId = dutySession.kittyId,
        maxCallsignLength = state.maxCallsignLength,
        maxDepartmentMessageLength = state.maxDepartmentMessageLength,
        departments = state.departments,
        callsignExample = state.callsignExample or Config.CallsignExample
    })
    if dutySession.active and phoneOpen then
        TriggerServerEvent('kittybodycam:requestFeeds')
    end
end)

RegisterNetEvent('kittybodycam:loginResult', function(result)
    if type(result) ~= 'table' then
        return
    end
    if not result.success then
        SendNUIMessage({ action = 'loginError', message = result.message or 'Unable to sign in.' })
        return
    end
    dutySession.active = true
    dutySession.callsign = result.callsign
    dutySession.department = result.department
    dutySession.kittyId = result.kittyId
    bodycam.unitNumber = result.callsign:match('%d+$') or result.callsign
    persistSettings()
    SendNUIMessage({
        action = 'dutyState',
        active = true,
        callsign = dutySession.callsign,
        department = dutySession.department,
        kittyId = dutySession.kittyId,
        maxCallsignLength = result.maxCallsignLength,
        maxDepartmentMessageLength = result.maxDepartmentMessageLength,
        departments = result.departments,
        callsignExample = Config.CallsignExample
    })
    -- Re-publish the local camera state after sign-in. If the bodycam was
    -- enabled before the duty session, the server previously rejected its
    -- state because the player was not yet on duty, leaving the feed invisible.
    TriggerServerEvent('kittybodycam:updateState', {
        active = bodycam.active,
        overlay = bodycam.overlay,
        unitNumber = bodycam.unitNumber
    })
    TriggerServerEvent('kittybodycam:requestFeeds')
    TriggerServerEvent('kittybodycam:requestDutyRoster')
end)

RegisterNetEvent('kittybodycam:bodycamForcedStop', function()
    bodycam.active = false
    lastBeepAt = nil
    setBodycamCamera(false)
    TriggerServerEvent('kittybodycam:updateState', {
        active = false,
        overlay = bodycam.overlay,
        unitNumber = bodycam.unitNumber
    })
    SendNUIMessage({
        action = 'bodycamState',
        active = false,
        overlay = bodycam.overlay,
        mode = bodycam.mode,
        unitNumber = bodycam.unitNumber
    })
end)

RegisterNetEvent('kittybodycam:departmentMessage', function(message)
    SendNUIMessage({ action = 'departmentMessage', message = message })
    notify(('Department message from %s'):format(message.callsign or 'Unit'))
end)

RegisterNetEvent('kittybodycam:phoneMessageError', function(message)
    SendNUIMessage({ action = 'phoneMessageError', message = message })
end)

RegisterNetEvent('kittybodycam:departmentMessageSent', function()
    SendNUIMessage({ action = 'departmentMessageSent' })
end)

RegisterNetEvent('kittybodycam:liveError', function(message)
    SendNUIMessage({ action = 'phoneError', message = message })
end)

RegisterNetEvent('kittybodycam:startRemoteView', function(feed)
    SetNuiFocus(false, false)
    setBodycamCamera(false)

    if not setRemoteCamera(feed.serverId) then
        TriggerServerEvent('kittybodycam:stopLive')
        if bodycam.active and bodycam.mode == 'chest' then
            setBodycamCamera(true)
        end
        SetNuiFocus(true, true)
        SendNUIMessage({ action = 'phoneError', message = 'That player is not currently streamed in. Refresh the camera list and try again.' })
        notify('The selected player is not currently streamed in.')
        return
    end

    SendNUIMessage({ action = 'startLive', feed = feed })
end)

RegisterNetEvent('kittybodycam:stopRemoteView', function()
    stopRemoteCamera()
    SendNUIMessage({ action = 'stopLive' })
end)

CreateThread(function()
    while true do
        if bodycam.active then
            local now = GetGameTimer()
            if lastBeepAt and now - lastBeepAt >= Config.BeepIntervalMs then
                lastBeepAt = now
                SendNUIMessage({ action = 'deviceBeep', overlay = bodycam.overlay })
            end
        end

        local camera, ped
        if remoteTargetId then
            local player = GetPlayerFromServerId(remoteTargetId)
            if player == -1 or not DoesEntityExist(GetPlayerPed(player)) then
                stopRemoteCamera()
                SendNUIMessage({ action = 'stopLive' })
                notify('The bodycam feed has ended.')
            else
                camera = remoteCamera
                ped = GetPlayerPed(player)
            end
        elseif bodycamCamera then
            camera = bodycamCamera
            ped = PlayerPedId()
        end

        if camera and ped and DoesEntityExist(ped) then
            local isOwnCamera = camera == bodycamCamera and not remoteTargetId
            local isAimingNow = isOwnCamera and getCameraAimState(ped)
            local mouseX, mouseY = 0.0, 0.0

            -- While aiming, do NOT disable look controls: GTA needs the real mouse input
            -- to drive weapon aim and the gameplay camera. The scripted bodycam copies
            -- that rotation in updateBodyCameraTransform().
            if not isAimingNow then
                DisableControlAction(0, 1, true)
                DisableControlAction(0, 2, true)
                mouseX = GetDisabledControlNormal(0, 1)
                mouseY = GetDisabledControlNormal(0, 2)
            end

            if isOwnCamera and not isAimingNow then
                -- Outside aiming, mouse right turns the officer and camera together.
                local newHeading = normalizeHeading(GetEntityHeading(ped) - mouseX * 8.0)
                SetEntityHeading(ped, newHeading)
                cameraBaseHeading = newHeading
                cameraLookYaw = 0.0
            elseif not isAimingNow then
                cameraLookYaw = math.max(-85.0, math.min(85.0, cameraLookYaw - mouseX * 8.0))
            else
                -- Keep sprint/strafe direction aligned with where the player aims.
                local aimRot = GetGameplayCamRot(2)
                SetEntityHeading(ped, normalizeHeading(aimRot.z))
                cameraBaseHeading = normalizeHeading(aimRot.z)
            end
            cameraLookPitch = math.max(-35.0, math.min(35.0, cameraLookPitch - mouseY * 8.0))

            if remoteTargetId and IsControlJustPressed(0, 177) then
                TriggerServerEvent('kittybodycam:stopLive')
                stopRemoteCamera()
                SendNUIMessage({ action = 'stopLive' })
                camera = nil
                ped = nil
            end

            if not updateBodyCameraTransform(camera, ped) then
                if camera == remoteCamera then
                    stopRemoteCamera()
                    SendNUIMessage({ action = 'stopLive' })
                    notify('The remote bodycam chest bone is unavailable.')
                else
                    setBodycamCamera(false)
                    notify('The chest bone is unavailable; bodycam view was stopped.')
                end
            end
            Wait(0)
        else
            Wait(bodycam.active and 1000 or 500)
        end
    end
end)

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then
        return
    end

    setBodycamCamera(false)
    stopRemoteCamera(false)
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
end)


-- Running sound: plays for the wearer while running with an active bodycam,
-- and for a viewer while the watched cop is running on a live feed.
CreateThread(function()
    local lastRunSound = false
    while true do
        local wantsSound = false
        if remoteTargetId then
            local player = GetPlayerFromServerId(remoteTargetId)
            if player ~= -1 then
                local targetPed = GetPlayerPed(player)
                wantsSound = DoesEntityExist(targetPed)
                    and (IsPedRunning(targetPed) or IsPedSprinting(targetPed))
                    and not IsPedInAnyVehicle(targetPed, false)
            end
        elseif bodycam.active then
            local ped = PlayerPedId()
            wantsSound = (IsPedRunning(ped) or IsPedSprinting(ped)) and not IsPedInAnyVehicle(ped, false)
        end

        if wantsSound ~= lastRunSound then
            lastRunSound = wantsSound
            SendNUIMessage({ action = 'runSound', active = wantsSound })
        end
        Wait(150)
    end
end)
