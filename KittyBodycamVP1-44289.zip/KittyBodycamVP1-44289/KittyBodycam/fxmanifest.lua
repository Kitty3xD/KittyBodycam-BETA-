fx_version 'cerulean'
game 'gta5'

author 'KittyBodycam'
description 'Bodycam Script by KiTTy3xD'
version '1.0.4'

ui_page 'html/index.html'

shared_script 'config.lua'
client_script 'client.lua'
server_script 'server.lua'

files {
    'html/index.html',
    'html/style.css',
    'html/app.js',
    'html/*.png',
    'html/*.mp3'
}
